import glob
from PIL import Image
R = 'android/app/src/main/res'
L = Image.open('resources/logo.png').convert('RGBA')

def sq(s, pad=1.0):
    bg = Image.new('RGBA', (s, s), (255, 255, 255, 0))
    k = int(s * pad)
    l = L.resize((k, k), Image.LANCZOS)
    bg.alpha_composite(l, ((s - k) // 2, (s - k) // 2))
    return bg

def white(im):
    b = Image.new('RGBA', im.size, (255, 255, 255, 255))
    b.alpha_composite(im)
    return b

for d, a, f in [('mdpi', 48, 108), ('hdpi', 72, 162), ('xhdpi', 96, 216), ('xxhdpi', 144, 324), ('xxxhdpi', 192, 432)]:
    p = f'{R}/mipmap-{d}/'
    white(sq(a)).save(p + 'ic_launcher.png')
    white(sq(a)).save(p + 'ic_launcher_round.png')
    sq(f, .62).save(p + 'ic_launcher_foreground.png')

for p in glob.glob(R + '/drawable*/splash.png'):
    w, h = Image.open(p).size
    k = int(min(w, h) * .4)
    c = Image.new('RGBA', (w, h), (255, 255, 255, 255))
    c.alpha_composite(L.resize((k, k), Image.LANCZOS), ((w - k) // 2, (h - k) // 2))
    c.convert('RGB').save(p)
