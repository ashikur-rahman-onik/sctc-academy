window.XV = H => {
  const { $, $$, E, toast, S, sv, KEYS } = H;
  const nums = (...a) => a.flat(Infinity).filter(x => typeof x === 'number');
  const sum = a => a.reduce((s, x) => s + x, 0);
  const M = (v, k) => {
    const m = /^(>=|<=|<>|!=|>|<|=)?(.*)$/.exec(String(k)), o = m[1] || '=', x = (m[2] === '' || isNaN(m[2])) ? m[2] : +m[2];
    return o === '>' ? v > x : o === '<' ? v < x : o === '>=' ? v >= x : o === '<=' ? v <= x : (o === '<>' || o === '!=') ? v != x : v == x;
  };
  const F = {
    SUM: (...a) => sum(nums(...a)),
    AVERAGE: (...a) => { const n = nums(...a); return sum(n) / n.length; },
    MAX: (...a) => Math.max(...nums(...a)),
    MIN: (...a) => Math.min(...nums(...a)),
    COUNT: (...a) => nums(...a).length,
    COUNTA: (...a) => a.flat(Infinity).filter(x => x !== '').length,
    ROUND: (x, n = 0) => Math.round(x * 10 ** n) / 10 ** n,
    IF: (c, a, b) => c ? a : b,
    AND: (...a) => a.every(Boolean),
    OR: (...a) => a.some(Boolean),
    COUNTIF: (r, k) => r.flat().filter(v => M(v, k)).length,
    SUMIF: (r, k, s) => { const t = (s || r).flat(); return r.flat().reduce((z, v, i) => (M(v, k) && typeof t[i] === 'number') ? z + t[i] : z, 0); },
    VLOOKUP: (k, r, i) => { const w = r.find(x => x[0] == k); if (!w) throw new Error('NA'); return w[i - 1]; }
  };
  const D = [['নাম', 'বাংলা', 'ইংরেজি', 'গণিত'], ['Rahim', 78, 65, 90], ['Karim', 45, 30, 55], ['Sumi', 88, 92, 79], ['Jabbar', 32, 40, 28], ['Mitu', 67, 70, 81]];
  const TK = [
    ['Rahim-এর তিন বিষয়ের মোট নম্বর বের করুন', '=SUM(B2:D2)'],
    ['বাংলা বিষয়ের গড় নম্বর বের করুন', '=AVERAGE(B2:B6)'],
    ['গণিতে সর্বোচ্চ নম্বর কত?', '=MAX(D2:D6)'],
    ['Jabbar-এর বাংলা (B5) ৩৩ বা বেশি হলে "Pass", নইলে "Fail" লিখুন', '=IF(B5>=33,"Pass","Fail")'],
    ['বাংলায় ৫০-এর বেশি পেয়েছে কতজন?', '=COUNTIF(B2:B6,">50")'],
    ['বাংলায় ৫০-এর বেশি পাওয়াদের গণিত নম্বরের যোগফল', '=SUMIF(B2:B6,">50",D2:D6)'],
    ['VLOOKUP দিয়ে Sumi-র গণিত নম্বর খুঁজুন', '=VLOOKUP("Sumi",A2:D6,4,FALSE)'],
    ['গণিতের গড় দশমিক ছাড়া (ROUND) বের করুন', '=ROUND(AVERAGE(D2:D6),0)']
  ];
  let hl = new Set();
  const CI = c => c.toUpperCase().charCodeAt(0) - 65;
  const C = (c, r) => { const v = D[r - 1][CI(c)]; hl.add(c.toUpperCase() + r); return v; };
  const R = (a, b, c, d) => {
    const o = [];
    for (let r = b; r <= d; r++) { const w = []; for (let k = CI(a); k <= CI(c); k++) { w.push(D[r - 1][k]); hl.add(String.fromCharCode(65 + k) + r); } o.push(w); }
    return o;
  };
  const ev = src => {
    hl = new Set();
    let s = src.trim().replace(/[“”]/g, '"');
    if (s[0] !== '=') throw new Error('=');
    s = s.slice(1);
    if (!/^[A-Za-z0-9\s:,.()"+\-*\/<>=&%$]*$/.test(s)) throw new Error('chars');
    s = s.replace(/([A-Za-z]+)\(/g, (m, f) => f.toUpperCase() + '(')
      .replace(/\bFALSE\b/gi, 'false').replace(/\bTRUE\b/gi, 'true')
      .replace(/<>/g, '!=').replace(/([<>!=]?)=(?!=)/g, (m, p) => p ? m : '==').replace(/&/g, '+')
      .replace(/\$?\b([A-D])\$?(\d+):\$?([A-D])\$?(\d+)\b/gi, (m, a, b, c, d) => `R("${a}",${b},"${c}",${d})`)
      .replace(/\$?\b([A-D])\$?(\d+)\b/gi, (m, a, b) => `C("${a}",${b})`);
    if (!(s.match(/[A-Za-z_]\w*(?=\s*\()/g) || []).every(n => n === 'R' || n === 'C' || Object.prototype.hasOwnProperty.call(F, n))) throw new Error('fn');
    const r = new Function('F', 'R', 'C', 'with(F){return (' + s + ');}')(F, R, C);
    if (r === undefined || (typeof r === 'number' && !isFinite(r))) throw new Error('v');
    return r;
  };
  const fm = r => typeof r === 'number' ? String(+r.toFixed(4)) : String(r);
  const JOBS = [
    ['🏢 অফিস সহকারী / ডেটা এন্ট্রি', 'SUM, AVERAGE, COUNTA, TRIM, IF, VLOOKUP', 'Ctrl+C/V/Z/S, Ctrl+Shift+L (Filter), Alt+=, Ctrl+Home', 'প্রতিদিন ৫০ সারি ডেটা টাইপ করুন, ভুল খুঁজে ঠিক করুন। লক্ষ্য: ৩০+ WPM।'],
    ['💰 হিসাবরক্ষক / ক্যাশিয়ার', 'SUM, SUMIF, ROUND, IF, VLOOKUP, Pivot Table', 'Alt+=, Ctrl+1 (Format Cells), F4 ($ লক), Ctrl+;', 'দৈনিক ক্যাশ বুক ও মাসিক আয়-ব্যয় সারাংশ নিজে বানান।'],
    ['🎓 শিক্ষক / ইনস্টিটিউট অ্যাডমিন', 'AVERAGE, IF, COUNTIF, MAX, MIN, RANK', 'Ctrl+B/I/U, Ctrl+P, Ctrl+F, Ctrl+Enter (Word)', 'রেজাল্ট শীট ও উপস্থিতি রিপোর্ট বানান, Pass/Fail ও Grade বসান।'],
    ['🛒 দোকান / স্টোর অপারেটর', 'SUMPRODUCT, SUMIF, COUNTIF, VLOOKUP, XLOOKUP', 'Ctrl+Shift+L, Ctrl+D (নিচে কপি), Ctrl+Space', 'স্টক ও বিক্রির শীট বানিয়ে লাভ-ক্ষতি হিসাব করুন।']
  ];
  return {
    pc: {
      t: '৩D কম্পিউটার পার্টস',
      h: () => '<canvas id="gl"></canvas><div class="box" id="pi">👆 কোনো অংশে ট্যাপ করুন, আঙুল দিয়ে ঘুরিয়ে দেখুন।</div>',
      i() {
        const cv = $('#gl'), pi = $('#pi');
        if (!window.THREE) { pi.textContent = '3D লোড হয়নি — অ্যাপ আপডেট করুন।'; return; }
        const T = THREE, w = cv.clientWidth || 320, h = 300;
        let r;
        try { r = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: true }); } catch (e) { pi.textContent = 'এই ফোনে 3D চালানো যাচ্ছে না।'; return; }
        r.setPixelRatio(Math.min(devicePixelRatio || 1, 2)); r.setSize(w, h, false);
        const sc = new T.Scene(), cam = new T.PerspectiveCamera(45, w / h, .1, 50);
        cam.position.set(0, 2.8, 9); cam.lookAt(0, 1, 0);
        sc.add(new T.AmbientLight(0xffffff, .75));
        const dl = new T.DirectionalLight(0xffffff, .9); dl.position.set(3, 6, 5); sc.add(dl);
        const g = new T.Group(); g.rotation.y = -.5; sc.add(g);
        const mk = (p, s, c, e) => { const m = new T.Mesh(new T.BoxGeometry(...s), new T.MeshStandardMaterial({ color: c, roughness: .5, emissive: e || 0 })); m.position.set(...p); g.add(m); return m; };
        mk([0, .55, -.05], [.3, .9, .3], 0x444444); mk([0, .05, 0], [1.1, .1, .7], 0x555555);
        const P = [
          ['🖥️ মনিটর', 'আউটপুট ডিভাইস — কম্পিউটারের ছবি ও লেখা দেখায়।', [0, 1.9, 0], [3.2, 2, .18], 0x1b2a4a, 0x0a2a55],
          ['📦 CPU কেস', 'কম্পিউটারের মস্তিষ্ক — Processor, RAM, Hard Disk, Motherboard এখানে থাকে। Power বাটনও এখানে।', [-2.9, 1.1, 0], [1.1, 2.2, 1.7], 0x3aaa35, 0],
          ['⌨️ কিবোর্ড', 'ইনপুট ডিভাইস — টাইপ ও শর্টকাট কমান্ড দেওয়ার জন্য।', [0, .2, 1.7], [3.2, .16, 1.1], 0xdddddd, 0],
          ['🖱️ মাউস', 'ইনপুট ডিভাইস — Click, Double Click, Right Click ও Scroll করে কাজ করা যায়।', [2.3, .2, 1.7], [.45, .16, .7], 0x0d4f8b, 0]
        ];
        const pk = P.map(p => { const m = mk(p[2], p[3], p[4], p[5]); m.userData = { i: p[0] + ' — ' + p[1], e: p[5] }; return m; });
        let dn = 0, mv = 0, x0 = 0, sel = null;
        const ray = new T.Raycaster();
        const pick = e => {
          const b = cv.getBoundingClientRect();
          ray.setFromCamera({ x: (e.clientX - b.left) / b.width * 2 - 1, y: -((e.clientY - b.top) / b.height * 2 - 1) }, cam);
          const t = ray.intersectObjects(pk)[0];
          if (sel) { sel.material.emissive.setHex(sel.userData.e); sel.scale.setScalar(1); }
          sel = t ? t.object : null;
          if (sel) { sel.material.emissive.setHex(0x2a7a2a); pi.textContent = sel.userData.i; }
        };
        cv.onpointerdown = e => { dn = 1; mv = 0; x0 = e.clientX; cv.setPointerCapture(e.pointerId); };
        cv.onpointermove = e => { if (!dn) return; const d = e.clientX - x0; x0 = e.clientX; mv += Math.abs(d); g.rotation.y += d * .01; };
        cv.onpointerup = e => { dn = 0; if (mv < 6) pick(e); };
        const tick = () => {
          if (!document.body.contains(cv)) { r.dispose(); return; }
          if (!dn && !sel) g.rotation.y += .004;
          if (sel) sel.scale.setScalar(1 + .04 * Math.sin(Date.now() / 200));
          r.render(sc, cam); requestAnimationFrame(tick);
        };
        tick();
      }
    },
    quiz: {
      t: 'শর্টকাট কুইজ',
      h: () => '<div class="box"><b id="qs">স্কোর: 0/0</b></div><div class="box" id="qq"></div><div id="qo"></div>',
      i() {
        let ok = 0, n = 0;
        const rnd = () => KEYS[Math.random() * KEYS.length | 0];
        const nx = () => {
          if (!$('#qq')) return;
          const k = rnd(), o = [k];
          while (o.length < 4) { const x = rnd(); if (!o.includes(x)) o.push(x); }
          o.sort(() => Math.random() - .5);
          $('#qq').innerHTML = `কোন শর্টকাট: <b>${E(k[1])}</b>?`;
          $('#qo').innerHTML = o.map((x, i) => `<button class="btn opt" data-i="${i}" style="width:100%;margin-bottom:10px;background:var(--c)">${E(x[0])}</button>`).join('');
          $$('.opt').forEach(b => b.onclick = () => {
            n++;
            const good = o[b.dataset.i] === k;
            if (good) ok++; else toast('সঠিক: ' + k[0]);
            b.style.background = good ? 'var(--g)' : '#c0392b';
            $$('.opt').forEach(c => c.disabled = true);
            $('#qs').textContent = `স্কোর: ${ok}/${n}`;
            setTimeout(nx, 1000);
          });
        };
        nx();
      }
    },
    sheet: {
      t: 'এক্সেল প্র্যাকটিস',
      h: () => '<div class="sheet" id="sh"></div><div class="box"><small id="tn"></small><p id="tq"></p></div><input class="s mono" id="fi" autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false"><div class="box" id="fr"></div><div class="row"><button class="btn" id="fc">✓ যাচাই</button><button class="btn alt" id="fh">💡 হিন্ট</button></div><div class="row"><button class="btn" id="fp" style="background:var(--c)">‹ আগের</button><button class="btn" id="fn" style="background:var(--c)">পরের ›</button></div><div class="box"><small>ফর্মুলা লিখলেই সবুজ ঘরগুলো উঠে আসবে — দেখুন Excel কোন ঘর নিয়ে হিসাব করছে।</small></div>',
      i() {
        let k = 0;
        const fi = $('#fi');
        $('#sh').innerHTML = '<div class="h"></div>' + ['A', 'B', 'C', 'D'].map(c => `<div class="h">${c}</div>`).join('') +
          D.map((r, i) => `<div class="h">${i + 1}</div>` + r.map((v, j) => `<div id="c_${String.fromCharCode(65 + j)}${i + 1}">${E(v)}</div>`).join('')).join('');
        const lab = () => { $('#tn').textContent = `টাস্ক ${k + 1}/${TK.length} · সমাধান ${(S.xl || []).length}`; $('#tq').textContent = TK[k][0] + ((S.xl || []).includes(k) ? ' ✅' : ''); };
        const run = () => {
          $$('#sh .hl').forEach(e => e.classList.remove('hl'));
          let t = null;
          try { t = fm(ev(fi.value)); } catch (e) {}
          $('#fr').innerHTML = 'ফলাফল: <b>' + (t === null ? '—' : E(t)) + '</b>';
          hl.forEach(id => { const e = $('#c_' + id); if (e) e.classList.add('hl'); });
          return t;
        };
        const load = () => { lab(); fi.value = '='; run(); };
        fi.oninput = run;
        $('#fh').onclick = () => { fi.value = TK[k][1]; run(); };
        $('#fp').onclick = () => { k = (k + TK.length - 1) % TK.length; load(); };
        $('#fn').onclick = () => { k = (k + 1) % TK.length; load(); };
        $('#fc').onclick = () => {
          let e; try { e = fm(ev(TK[k][1])); } catch (x) {}
          const t = run();
          if (t !== null && t === e) { S.xl = S.xl || []; if (!S.xl.includes(k)) { S.xl.push(k); sv(); } lab(); toast('✅ সঠিক! দারুণ হয়েছে'); }
          else toast('❌ ফলাফল মেলেনি — 💡 হিন্ট দেখুন');
        };
        load();
      }
    },
    career: {
      t: 'চাকরির গাইড (BD)',
      h: () => JOBS.map(j => `<details class="box"><summary>${j[0]}</summary><p><b>ফর্মুলা:</b> ${E(j[1])}</p><p><b>শর্টকাট:</b> ${E(j[2])}</p><p><b>প্র্যাকটিস:</b> ${E(j[3])}</p></details>`).join('') +
        '<div class="box"><b>📅 ৪ সপ্তাহের প্ল্যান</b><p>সপ্তাহ ১: কিবোর্ড, টাইপিং ও Word বেসিক।</p><p>সপ্তাহ ২: Excel বেসিক — SUM, AVERAGE, IF।</p><p>সপ্তাহ ৩: COUNTIF, SUMIF, VLOOKUP, Pivot Table।</p><p>সপ্তাহ ৪: নিজে একটি রেজাল্ট বা হিসাবের শীট বানিয়ে মক টেস্ট দিন।</p><p><b>প্রতিদিন:</b> ২০ মিনিট টাইপিং + ১০ মিনিট শর্টকাট কুইজ + ১টি Excel টাস্ক।</p></div>'
    }
  };
};
