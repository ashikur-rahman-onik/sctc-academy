window.WK = [['Ctrl + Home / End', 'ডকুমেন্টের শুরু / শেষে যান (Word)'], ['Ctrl + Shift + C / V', 'ফরম্যাট কপি / পেস্ট (Word)'], ['Ctrl + [ / ]', 'ফন্ট ১ পয়েন্ট ছোট / বড় (Word)'], ['Ctrl + Shift + > / <', 'ফন্ট সাইজ ধাপে বাড়ান / কমান (Word)'], ['Ctrl + D', 'Font ডায়ালগ (Word)'], ['Ctrl + J', 'Justify অ্যালাইন (Word)'], ['Ctrl + 1 / 2 / 5', 'লাইন স্পেস ১ / ২ / ১.৫ (Word)'], ['Ctrl + K', 'Hyperlink বসান (Word)'], ['Ctrl + G', 'নির্দিষ্ট পেজে যান (Word)'], ['Ctrl + W', 'ডকুমেন্ট বন্ধ (Word)'], ['Ctrl + Alt + 1 / 2 / 3', 'Heading 1 / 2 / 3 (Word)'], ['Ctrl + Backspace / Delete', 'আগের / পরের পুরো শব্দ মোছা (Word)'], ['Ctrl + ← / →', 'এক শব্দ করে কার্সার সরান (Word)'], ['Ctrl + Shift + ← / →', 'এক শব্দ করে সিলেক্ট (Word)'], ['Ctrl + Shift + Home / End', 'কার্সার থেকে শুরু / শেষ পর্যন্ত সিলেক্ট'], ['Shift + F3', 'ছোট/বড় হাতের অক্ষর বদল (Word)'], ['Ctrl + Shift + A', 'সব অক্ষর Capital (Word)'], ['Ctrl + Shift + L', 'Bullet তালিকা (Word)'], ['Ctrl + M / Ctrl + T', 'Indent বাড়ান / Hanging indent (Word)'], ['Ctrl + Q', 'Paragraph ফরম্যাট মোছা (Word)'], ['Ctrl + Space', 'Character ফরম্যাট মোছা (Word)'], ['Ctrl + Shift + E', 'Track Changes চালু (Word)'], ['Ctrl + Alt + M', 'Comment বসান (Word)'], ['Alt + Shift + D / T', 'আজকের তারিখ / সময় বসান (Word)'], ['Shift + Enter', 'নতুন লাইন, প্যারাগ্রাফ না ভেঙে (Word)'], ['F4', 'শেষ কাজটি আবার করুন (Word/Excel)'], ['F7', 'বানান ও ব্যাকরণ চেক (Word)'], ['Ctrl + F2', 'Print Preview (Word)'], ['Ctrl + = / Ctrl + Shift + =', 'Subscript / Superscript (Word)']];

window.PRO = H => {
  const { $, $$, E, toast } = H;
  const chips = (a, on) => `<div class="chips">${a.map((x, i) => `<button class="chip${i === on ? ' on' : ''}" data-c="${i}">${x}</button>`).join('')}</div>`;
  const bind = f => $$('[data-c]').forEach(b => b.onclick = () => { $$('[data-c]').forEach(c => c.classList.toggle('on', c === b)); f(+b.dataset.c); });

  /* ---------- 3D PC parts (realistic textures) ---------- */
  const PARTS = [
    ['🖥️ মনিটর', 'monitor', 'আউটপুট ডিভাইস। কম্পিউটারের ছবি ও লেখা দেখায়। পেছনে HDMI / VGA পোর্ট ও পাওয়ার ক্যাবল লাগে। মাপ ইঞ্চিতে (যেমন ১৯", ২২", ২৪")।'],
    ['📦 CPU কেস', 'case', 'কম্পিউটারের মস্তিষ্ক। ভেতরে Motherboard, Processor, RAM, Hard Disk/SSD, Power Supply থাকে। সামনে Power বাটন, USB পোর্ট, হেডফোন জ্যাক।'],
    ['⌨️ কিবোর্ড', 'keyboard', 'ইনপুট ডিভাইস। Alphabet, Number, Function (F1–F12), Arrow ও Ctrl/Alt/Shift কী আছে। টাইপ ও শর্টকাটের জন্য।'],
    ['🖱️ মাউস', 'mouse', 'ইনপুট ডিভাইস। বাঁ বাটন = Select/Click, ডান বাটন = মেনু, মাঝের চাকা = Scroll।']
  ];
  const pc = {
    t: '৩D কম্পিউটার পার্টস',
    h: () => `<canvas id="gl"></canvas>${chips(PARTS.map(p => p[0]), -1)}<div class="box" id="pi">👆 অংশে ট্যাপ করুন বা নিচের বাটন চাপুন। আঙুল দিয়ে ঘুরান।</div><div id="ph"></div>`,
    i() {
      const cv = $('#gl'), pi = $('#pi');
      if (!window.THREE) { pi.textContent = '3D লোড হয়নি।'; return; }
      const T = THREE, w = cv.clientWidth || 320, h = 320;
      let r; try { r = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: true }); } catch (e) { pi.textContent = 'এই ফোনে 3D চলছে না।'; return; }
      r.setPixelRatio(Math.min(devicePixelRatio || 1, 2)); r.setSize(w, h, false);
      const sc = new T.Scene(), cam = new T.PerspectiveCamera(42, w / h, .1, 60);
      cam.position.set(0, 3.6, 10.5); cam.lookAt(0, 1.1, 0);
      sc.add(new T.HemisphereLight(0xffffff, 0x223344, .9));
      const dl = new T.DirectionalLight(0xffffff, .8); dl.position.set(4, 8, 6); sc.add(dl);
      const tx = (W, Hh, f) => { const c = document.createElement('canvas'); c.width = W; c.height = Hh; f(c.getContext('2d'), W, Hh); const t = new T.CanvasTexture(c); t.anisotropy = 4; return t; };
      const rr = (x, a, b, c, d, q) => { x.beginPath(); x.moveTo(a + q, b); x.arcTo(a + c, b, a + c, b + d, q); x.arcTo(a + c, b + d, a, b + d, q); x.arcTo(a, b + d, a, b, q); x.arcTo(a, b, a + c, b, q); x.closePath(); };
      const M = (o) => new T.MeshStandardMaterial(Object.assign({ roughness: .45, metalness: .2 }, o));
      const B = (g, s, o, p) => { const m = new T.Mesh(new T.BoxGeometry(...s), M(o)); m.position.set(...p); g.add(m); return m; };
      const root = new T.Group(); root.rotation.y = -.45; sc.add(root);
      const desk = B(root, [9, .2, 4.6], { color: 0x7a5233, roughness: .8, metalness: 0 }, [0, -.1, .4]);
      const grp = () => { const g = new T.Group(); root.add(g); return g; };
      const G = [grp(), grp(), grp(), grp()];
      // monitor
      G[0].position.set(.4, 0, -.9);
      B(G[0], [3.5, 2.15, .16], { color: 0x14171c, metalness: .5 }, [0, 1.95, 0]);
      const scr = new T.Mesh(new T.PlaneGeometry(3.3, 1.95), M({ map: tx(512, 300, (x, W, Hh) => { const g = x.createLinearGradient(0, 0, W, Hh); g.addColorStop(0, '#2b7de0'); g.addColorStop(1, '#0a2f6b'); x.fillStyle = g; x.fillRect(0, 0, W, Hh); x.font = '34px sans-serif'; ['🗑️', '📁', '🌐', '📝'].forEach((e, k) => x.fillText(e, 18, 48 + k * 56)); x.fillStyle = '#10192bee'; x.fillRect(0, Hh - 28, W, 28); x.fillStyle = '#4aa8ff'; x.fillRect(8, Hh - 22, 16, 16); x.fillStyle = '#fff'; x.font = '13px sans-serif'; x.fillText('10:30 AM', W - 70, Hh - 9); }), roughness: .2, metalness: 0, emissive: 0xffffff, emissiveIntensity: .35 }));
      scr.material.emissiveMap = scr.material.map; scr.position.set(0, 1.95, .09); G[0].add(scr);
      B(G[0], [.32, .7, .2], { color: 0x2a2d33, metalness: .6 }, [0, .6, -.05]);
      const bs = new T.Mesh(new T.CylinderGeometry(.75, .85, .08, 32), M({ color: 0x2a2d33, metalness: .6 })); bs.position.set(0, .06, .05); G[0].add(bs);
      // case
      G[1].position.set(-3.1, 0, -.4); G[1].rotation.y = .45;
      B(G[1], [1.25, 2.5, 1.9], { color: 0x1e2228, metalness: .5 }, [0, 1.25, 0]);
      const fr = new T.Mesh(new T.PlaneGeometry(1.15, 2.4), M({ map: tx(256, 512, (x, W, Hh) => { x.fillStyle = '#242a31'; x.fillRect(0, 0, W, Hh); x.fillStyle = '#0c0f13'; for (let k = 0; k < 14; k++) x.fillRect(30, 250 + k * 17, 196, 7); x.fillStyle = '#12161b'; rr(x, 30, 40, 196, 26, 4); x.fill(); x.fillStyle = '#555'; x.fillRect(40, 52, 176, 3); x.strokeStyle = '#8be28a'; x.lineWidth = 6; x.beginPath(); x.arc(128, 128, 24, -1.2, 4.3); x.stroke(); x.beginPath(); x.moveTo(128, 100); x.lineTo(128, 126); x.stroke(); x.fillStyle = '#3aff6a'; x.beginPath(); x.arc(200, 128, 5, 0, 7); x.fill(); x.fillStyle = '#000'; [[60, 190], [100, 190]].forEach(p => x.fillRect(p[0], p[1], 28, 11)); x.fillStyle = '#9ab'; x.font = '14px sans-serif'; x.fillText('SCTC', 100, 480); }) })); fr.position.set(0, 1.25, .96); G[1].add(fr);
      // keyboard
      G[2].position.set(.2, 0, 1.6);
      B(G[2], [3.3, .16, 1.15], { color: 0x15181c }, [0, .08, 0]);
      const kb = new T.Mesh(new T.PlaneGeometry(3.15, 1.0), M({ map: tx(1024, 320, (x, W, Hh) => { x.fillStyle = '#15181c'; x.fillRect(0, 0, W, Hh); const R = [['Esc', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12', 'Del'], ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 'Back'], ['Tab', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']', '\\'], ['Caps', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', "'", 'Enter'], ['Shift', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 'Shift'], ['Ctrl', 'Win', 'Alt', 'Space', 'Alt', 'Ctrl']]; R.forEach((row, ri) => { const wd = ri === 5 ? [1.4, 1.2, 1.2, 6.2, 1.2, 1.4] : null; let tot = row.length; if (wd) tot = wd.reduce((a, b) => a + b); else if (ri > 0) { tot = row.length + (row[0].length > 2 ? .6 : 0) + (row[row.length - 1].length > 2 ? .6 : 0); } let px = 8; const u = (W - 16) / tot; row.forEach((k, ci) => { let ww = wd ? wd[ci] : 1; if (!wd && ri > 0 && (ci === 0 || ci === row.length - 1) && k.length > 2) ww = 1.6; x.fillStyle = '#e6e9ee'; rr(x, px + 2, 8 + ri * 50, ww * u - 4, 42, 6); x.fill(); x.fillStyle = '#222'; x.font = '17px sans-serif'; x.textAlign = 'center'; x.fillText(k, px + ww * u / 2, 36 + ri * 50); px += ww * u; }); }); }), roughness: .6, metalness: 0 }));
      kb.rotation.x = -Math.PI / 2; kb.position.set(0, .165, 0); G[2].add(kb);
      // mouse
      G[3].position.set(2.9, 0, 1.6);
      const ms = new T.Mesh(new T.SphereGeometry(1, 32, 20), M({ color: 0x1b1f26, roughness: .3, metalness: .3 })); ms.scale.set(.32, .2, .52); ms.position.y = .15; G[3].add(ms);
      B(G[3], [.015, .02, .26], { color: 0x000000 }, [0, .34, -.18]);
      const wh = new T.Mesh(new T.CylinderGeometry(.045, .045, .09, 16), M({ color: 0x7ee08a, emissive: 0x2a8a3a })); wh.rotation.z = Math.PI / 2; wh.position.set(0, .33, -.2); G[3].add(wh);
      const ln = B(G[3], [.01, .01, .3], { color: 0x333 }, [0, .345, -.28]); ln.visible = false;
      // interaction
      const pk = []; G.forEach((g, k) => g.traverse(m => { if (m.isMesh) { m.userData.k = k; pk.push(m); } }));
      let dn = 0, mv = 0, x0 = 0, sel = -1;
      const info = k => { sel = k; pi.innerHTML = `<b>${PARTS[k][0]}</b><br>${E(PARTS[k][2])}`; $('#ph').innerHTML = `<img src="img/${PARTS[k][1]}.jpg" alt="" style="width:100%;border-radius:14px;margin-top:8px" onerror="this.remove()">`; $$('[data-c]').forEach(c => c.classList.toggle('on', +c.dataset.c === k)); };
      bind(info);
      const ray = new T.Raycaster();
      cv.onpointerdown = e => { dn = 1; mv = 0; x0 = e.clientX; cv.setPointerCapture(e.pointerId); };
      cv.onpointermove = e => { if (!dn) return; const d = e.clientX - x0; x0 = e.clientX; mv += Math.abs(d); root.rotation.y += d * .01; };
      cv.onpointerup = e => { dn = 0; if (mv < 6) { const b = cv.getBoundingClientRect(); ray.setFromCamera({ x: (e.clientX - b.left) / b.width * 2 - 1, y: -((e.clientY - b.top) / b.height * 2 - 1) }, cam); const t = ray.intersectObjects(pk)[0]; if (t) info(t.object.userData.k); } };
      const tick = () => {
        if (!document.body.contains(cv)) { r.dispose(); return; }
        if (!dn && sel < 0) root.rotation.y += .004;
        G.forEach((g, k) => g.scale.setScalar(k === sel ? 1 + .04 * Math.sin(Date.now() / 220) : 1));
        r.render(sc, cam); requestAnimationFrame(tick);
      };
      tick();
    }
  };

  /* ---------- Taskbar fixer (3D mock + steps) ---------- */
  const TB = [
    ['🙈 লুকিয়ে যায়', 'টাস্কবার নিচে দেখা যাচ্ছে না — Auto-hide চালু থাকলে এমন হয়।', [['টাস্কবার স্ক্রিনের নিচে নেই', 'hid'], ['স্ক্রিনের একদম নিচের কিনারায় মাউস/আঙুল নিন — উঠে আসবে', 'hid up'], ['টাস্কবারের ফাঁকা জায়গায় Right-click → Taskbar settings', 'up menu'], ['"Automatically hide the taskbar" Off করুন', 'dlg'], ['সমাধান ✅ টাস্কবার স্থায়ীভাবে ফিরেছে', '']]],
    ['↔️ পাশে সরে গেছে', 'টাস্কবার বাঁ/ডান/উপরে চলে গেছে (Windows 10)। Windows 11-এ টাস্কবার সবসময় নিচে থাকে।', [['টাস্কবার বাঁ পাশে চলে গেছে', 'side'], ['ফাঁকা জায়গায় Right-click → Taskbar settings', 'side menu'], ['"Taskbar location on screen" → Bottom বেছে নিন', 'dlg'], ['সমাধান ✅ টাস্কবার নিচে ফিরেছে', '']]],
    ['🧩 এলোমেলো আইকন', 'অনেক আইকন জমে টাস্কবার এলোমেলো।', [['আইকন ঠাসাঠাসি, এলোমেলো', 'mess'], ['অপ্রয়োজনীয় আইকনে Right-click → Unpin from taskbar', 'mess menu'], ['দরকারি আইকন ড্র্যাগ করে পছন্দমতো সাজান', ''], ['Taskbar settings → "Combine taskbar buttons" = Always', 'dlg'], ['সমাধান ✅ পরিচ্ছন্ন টাস্কবার', '']]],
    ['🧊 হ্যাং / ক্লিক হয় না', 'টাস্কবার আটকে গেছে, Start চাপলে সাড়া নেই।', [['টাস্কবার "Not responding"', 'frz'], ['কিবোর্ডে Ctrl + Shift + Esc চাপুন (Task Manager)', 'tm'], ['তালিকায় "Windows Explorer" বেছে Restart চাপুন', 'tm'], ['কয়েক সেকেন্ডে টাস্কবার ফিরবে। না এলে PC Restart করুন ✅', '']]]
  ];
  const taskbar = {
    t: 'টাস্কবার সমস্যা সমাধান',
    h: () => `<div class="dk3"><div class="dk" id="dk"><div class="icn"><span>🗑️<br>Bin</span><span>💻<br>This PC</span><span>📁<br>Files</span></div><div class="tbr"><b>⊞</b><span>🔍</span><span>🌐</span><span>📁</span><span>📝</span><span>📊</span><span class="ex">🎵</span><span class="ex">📷</span><span class="ex">🎮</span><span class="ex">💬</span><span class="ex">📧</span><i>10:30</i></div><div class="x-menu">⚙️ Taskbar settings<br>🗂️ Task Manager<br>🖥️ Show desktop</div><div class="x-dlg">⚙️ <b>Taskbar settings</b><br>☐ Automatically hide the taskbar<br>Taskbar location: <u>Bottom</u><br>Combine buttons: <u>Always</u></div><div class="x-tm">📊 <b>Task Manager</b><br>▸ Windows Explorer &nbsp; <u>[Restart]</u></div></div></div>${chips(TB.map(x => x[0]), 0)}<div class="box" id="tp"></div><ol class="steps" id="ts"></ol><div class="row"><button class="btn" id="tprev" style="background:var(--c)">‹ আগের</button><button class="btn" id="tnext">পরের ধাপ ›</button></div>`,
    i() {
      let s = 0, k = 0;
      const dk = $('#dk');
      const draw = () => { const sc = TB[s]; $('#tp').textContent = sc[1]; $('#ts').innerHTML = sc[2].map((x, j) => `<li class="${j === k ? 'on' : ''}">${x[0]}</li>`).join(''); dk.className = 'dk ' + sc[2][k][1]; };
      bind(i => { s = i; k = 0; draw(); });
      $('#tnext').onclick = () => { k = (k + 1) % TB[s][2].length; draw(); };
      $('#tprev').onclick = () => { k = (k + TB[s][2].length - 1) % TB[s][2].length; draw(); };
      draw();
    }
  };

  /* ---------- Interview ---------- */
  const IQ = [
    ['নিজের সম্পর্কে বলুন (Tell me about yourself)', 'নাম, পড়াশোনা, কম্পিউটার কোর্স, দক্ষতা — ৩০ সেকেন্ডে বলুন। পারিবারিক গল্প বাড়াবেন না।', '"My name is Rahim. I completed HSC and a computer course at SCTC. I can type, use MS Word, Excel and make reports. I want to grow in your company."'],
    ['কেন এই চাকরিতে আগ্রহী?', 'কোম্পানির কাজ আগে জেনে যান। শুধু "বেতনের জন্য" বলবেন না।', '"I want to use my computer skills in real work and learn from experienced people."'],
    ['আপনার সবচেয়ে বড় শক্তি ও দুর্বলতা', 'শক্তি: দ্রুত শেখা, নিয়মিত, সৎ। দুর্বলতা: এমন বলুন যা আপনি শুধরাচ্ছেন।', '"I am a fast learner. I used to be nervous speaking English, so I practice daily."'],
    ['বেতন কত আশা করেন?', 'ফ্রেশার হলে বাজারদর জেনে যান। নমনীয় থাকুন, প্রথমে শেখার সুযোগ গুরুত্ব দিন।', '"I expect a salary as per company policy. Learning is my first priority."'],
    ['টাইপিং স্পিড কত?', 'সত্যি বলুন। অফিসে সাধারণত ২৫–৩০ WPM আশা করে। টেস্টে ধরা পড়বে।', '"My typing speed is about 30 WPM with good accuracy."'],
    ['Excel-এ কী কী পারেন? (প্র্যাকটিক্যাল টেস্ট)', 'SUM, AVERAGE, IF, COUNTIF, SUMIF, VLOOKUP, Pivot, Chart। এই অ্যাপের "এক্সেল প্র্যাকটিস" থেকে অনুশীলন করুন।', '"I can use SUM, IF, VLOOKUP, SUMIF and make a Pivot Table and chart."'],
    ['Ctrl+C, V, Z, S কী করে?', 'শর্টকাট কুইজে ১০০% স্কোর করুন। এগুলো ইন্টারভিউয়ে প্রায়ই জিজ্ঞেস করে।', '"Copy, Paste, Undo and Save."'],
    ['কম্পিউটারে ফাইল হারিয়ে গেলে কী করবেন?', 'Recycle Bin, Win + E দিয়ে Search, Recent files, Ctrl+Z। এভাবে ধাপে বলুন।', '"I will check Recycle Bin, then search in File Explorer."'],
    ['ইন্টারভিউয়ে কী নিয়ে যাবেন?', 'CV ২ কপি, সার্টিফিকেট ফটোকপি, NID কপি, ছবি, কলম। সময়ের ১৫ মিনিট আগে পৌঁছান।', 'পরিষ্কার পোশাক, হাসিমুখ, "Assalamu Alaikum / Good morning sir" বলে ঢুকুন।'],
    ['আপনার কোনো প্রশ্ন আছে?', 'সবসময় একটি প্রশ্ন করুন: কাজের ধরন বা ট্রেনিং নিয়ে। বেতন/ছুটি নিয়ে প্রথমেই নয়।', '"What will my daily responsibilities be?"']
  ];
  const interview = {
    t: 'ইন্টারভিউ প্রস্তুতি (BD)',
    h: () => `<div class="row"><button class="btn" id="iq">🎲 র‍্যান্ডম প্রশ্ন</button></div><div class="box" id="ir">কার্ডে ট্যাপ করে উত্তর দেখুন। আগে নিজে উত্তর বলার চেষ্টা করুন।</div>` + IQ.map((q, n) => `<details class="box" id="q${n}"><summary>${n + 1}. ${E(q[0])}</summary><p><b>কীভাবে বলবেন:</b> ${E(q[1])}</p><p><b>নমুনা উত্তর:</b><br><small>${E(q[2])}</small></p></details>`).join(''),
    i() { $('#iq').onclick = () => { const n = Math.random() * IQ.length | 0; $$('details').forEach(d => d.open = false); const d = $('#q' + n); d.open = true; $('#ir').innerHTML = '🎤 <b>' + E(IQ[n][0]) + '</b><br><small>আগে নিজে উত্তর দিন, তারপর নিচে মিলিয়ে নিন।</small>'; d.scrollIntoView({ behavior: 'smooth', block: 'center' }); }; }
  };

  /* ---------- Sales report ---------- */
  const SD = [['Product', 'Qty', 'Price', 'Total'], ['Pen', 10, 12], ['Copy', 5, 60], ['Pen', 20, 12], ['File', 4, 45], ['Copy', 8, 60], ['File', 6, 45]];
  SD.forEach((r, i) => { if (i) r[3] = r[1] * r[2]; });
  const sumT = SD.slice(1).reduce((a, r) => a + r[3], 0), penT = SD.filter(r => r[0] === 'Pen').reduce((a, r) => a + r[3], 0), mx = Math.max(...SD.slice(1).map(r => r[3]));
  const col = (c, a, b) => { const o = []; for (let r = a; r <= b; r++) o.push(c + r); return o; };
  const SS = [
    ['১. হেডিং ও ডেটা সাজান', 'প্রথম সারিতে হেডিং, নিচে প্রতিটি বিক্রির এন্ট্রি। একটি সারি = একটি বিক্রি।', '', 'A1 → D1', ['A1', 'B1', 'C1', 'D1', ...col('A', 2, 7), ...col('B', 2, 7), ...col('C', 2, 7)]],
    ['২. Total বের করুন', 'D2 ঘরে সূত্র লিখে Enter দিন, তারপর ঘরের কোণা নিচে টেনে (Fill Handle) বাকি সারিতে কপি করুন।', '=B2*C2', 'ফলাফল: ' + SD[1][3], ['B2', 'C2', 'D2']],
    ['৩. মোট বিক্রি', 'নিচে ফাঁকা ঘরে ক্লিক করে Alt + = চাপুন (AutoSum)।', '=SUM(D2:D7)', 'ফলাফল: ' + sumT, col('D', 2, 7)],
    ['৪. পণ্যভিত্তিক বিক্রি', 'নির্দিষ্ট পণ্যের মোট বিক্রি দেখতে SUMIF।', '=SUMIF(A2:A7,"Pen",D2:D7)', 'ফলাফল: ' + penT, ['A2', 'A4', 'D2', 'D4']],
    ['৫. সর্বোচ্চ বিক্রি', 'কোন এন্ট্রিতে সবচেয়ে বেশি বিক্রি হলো।', '=MAX(D2:D7)', 'ফলাফল: ' + mx, col('D', 2, 7)],
    ['৬. Pivot Table', 'ডেটা সিলেক্ট করুন → Insert → PivotTable → OK। Product কে Rows এ, Total কে Values এ টেনে দিন। প্রতি পণ্যের সারাংশ রিপোর্ট তৈরি।', 'Insert → PivotTable', 'মাসিক রিপোর্টে সবচেয়ে বেশি কাজে লাগে', [...col('A', 1, 7), ...col('D', 1, 7)]],
    ['৭. Chart ও প্রিন্ট', 'Pivot বা Total সিলেক্ট → Insert → Column Chart। Title দিন। তারপর Ctrl + P দিয়ে প্রিন্ট। Page Layout → Landscape।', 'Insert → Chart', 'রিপোর্টে ছবি থাকলে বুঝতে সহজ', [...col('A', 1, 7), ...col('D', 1, 7)]]
  ];
  const sales = {
    t: 'সেলস রিপোর্ট বানানো',
    h: () => `<div class="sheet" id="sh2"><div class="h"></div>${'ABCD'.split('').map(c => `<div class="h">${c}</div>`).join('')}${SD.map((r, i) => `<div class="h">${i + 1}</div>` + [0, 1, 2, 3].map(j => `<div id="q_${'ABCD'[j]}${i + 1}">${r[j] === undefined ? '' : E(r[j])}</div>`).join('')).join('')}</div><div class="box"><b id="sn"></b><p id="sd"></p><code class="mono" id="sf" style="color:#8be28a"></code><small id="sr"></small></div><div class="row"><button class="btn" id="sp" style="background:var(--c)">‹ আগের</button><button class="btn" id="sx">পরের ›</button></div>`,
    i() {
      let k = 0;
      const d = () => { $$('#sh2 .hl').forEach(e => e.classList.remove('hl')); const s = SS[k]; $('#sn').textContent = s[0]; $('#sd').textContent = s[1]; $('#sf').textContent = s[2]; $('#sr').textContent = s[3]; s[4].forEach(id => { const e = $('#q_' + id); if (e) e.classList.add('hl'); }); };
      $('#sx').onclick = () => { k = (k + 1) % SS.length; d(); }; $('#sp').onclick = () => { k = (k + SS.length - 1) % SS.length; d(); }; d();
    }
  };

  /* ---------- Cash register ---------- */
  const IT = [['✏️ কলম', 10], ['📓 খাতা', 60], ['📁 ফাইল', 45], ['✂️ কাঁচি', 35], ['📏 স্কেল', 20], ['🧴 আঠা', 25]];
  const NOTE = [1000, 500, 200, 100, 50, 20, 10, 5, 2, 1];
  const cash = {
    t: 'ক্যাশ রেজিস্টার',
    h: () => `<div class="grid" id="it">${IT.map((x, n) => `<button class="card" data-n="${n}"><b>${x[0]}</b><small>৳${x[1]}</small></button>`).join('')}</div><div class="box" id="bl" style="margin-top:12px"></div><input class="s mono" id="pd" type="number" inputmode="numeric" placeholder="গ্রাহক কত টাকা দিলেন?"><div class="box" id="cg"></div><div class="row"><button class="btn alt" id="cl">🗑️ নতুন বিল</button></div><div class="box"><b>📒 ক্যাশ বুকের নিয়ম</b><p>কলাম: তারিখ | বিবরণ | জমা (In) | খরচ (Out) | ব্যালেন্স</p><code>=SUM($C$2:C2)-SUM($D$2:D2)</code><p>দিন শেষে: শুরুর ক্যাশ + বিক্রি − খরচ = হাতে থাকা ক্যাশ। গুণে মিলিয়ে দেখুন; কম/বেশি হলে লিখে রাখুন।</p></div><div class="box"><b>✅ ক্যাশিয়ারের ৫ নিয়ম</b><p>১. টাকা নেওয়ার সময় উচ্চস্বরে গুনুন। ২. ফেরত দেওয়ার আগে বিল মিলান। ৩. ছেঁড়া/নকল নোট যাচাই করুন। ৪. ড্রয়ারে বড় নোট আলাদা রাখুন। ৫. দিন শেষে ক্যাশ মিলিয়ে সই করুন।</p></div>`,
    i() {
      const b = {};
      const d = () => {
        const ks = Object.keys(b); let sub = 0;
        $('#bl').innerHTML = ks.length ? ks.map(n => { sub += IT[n][1] * b[n]; return `<div>${IT[n][0]} × ${b[n]} = ৳${IT[n][1] * b[n]}</div>`; }).join('') + `<hr style="opacity:.2;margin:6px 0">Subtotal: ৳${sub}<br>VAT ৫%: ৳${Math.round(sub * .05)}<br><b>মোট: ৳${sub + Math.round(sub * .05)}</b>` : 'আইটেমে ট্যাপ করে বিল বানান।';
        const t = sub + Math.round(sub * .05), p = +$('#pd').value || 0;
        if (!ks.length) { $('#cg').textContent = ''; return; }
        if (p < t) { $('#cg').innerHTML = p ? `⚠️ আরও ৳${t - p} লাগবে` : 'পেমেন্ট লিখুন।'; return; }
        let c = p - t, o = []; NOTE.forEach(n => { const q = c / n | 0; if (q) { o.push(`৳${n} × ${q}`); c -= q * n; } });
        $('#cg').innerHTML = `ফেরত: <b>৳${p - t}</b><br><small>${o.join(' · ') || 'ফেরত নেই'}</small>`;
      };
      $$('[data-n]').forEach(x => x.onclick = () => { b[x.dataset.n] = (b[x.dataset.n] || 0) + 1; d(); });
      $('#pd').oninput = d; $('#cl').onclick = () => { Object.keys(b).forEach(k => delete b[k]); $('#pd').value = ''; d(); }; d();
    }
  };
  return { pc, taskbar, interview, sales, cash };
};
