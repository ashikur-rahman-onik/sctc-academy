window.CFG={repo:'__REPO__'};
