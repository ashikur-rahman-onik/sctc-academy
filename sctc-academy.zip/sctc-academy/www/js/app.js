(() => {
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const C = window.Capacitor || {}, P = C.Plugins || {};
const nat = !!(C.isNativePlatform && C.isNativePlatform());
const I = nat ? C.registerPlugin('ApkInstaller') : null;
const app = $('#app');
let S = {};
try { S = JSON.parse(localStorage.sctc || '{}'); } catch (e) {}
const sv = () => { try { localStorage.sctc = JSON.stringify(S); } catch (e) {} };
const E = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const wait = ms => new Promise(r => setTimeout(r, ms));
const toast = m => { const t = document.createElement('div'); t.id = 'toast'; t.textContent = m; document.body.append(t); setTimeout(() => t.remove(), 3200); };

const MODS = [['boot', '🖥️', 'কম্পিউটার চালু ও বন্ধ', 'Power On / Shutdown'], ['office', '📄', 'অফিস অ্যাপ ও মেনু', 'Word · Excel · PowerPoint'], ['keys', '⌨️', 'শর্টকাট কী', 'Keyboard Shortcuts'], ['excel', '📊', 'এক্সেল ফর্মুলা', 'Beginner → Advanced'], ['type', '⚡', 'টাইপিং প্র্যাকটিস', 'Speed & Accuracy'], ['upd', '⬇️', 'অ্যাপ আপডেট', 'নতুন ভার্সন']];
const LV = { B: 'Beginner', I: 'Intermediate', A: 'Advanced' };
const ON = ['পাওয়ার ক্যাবল ঠিক আছে দেখে CPU-র Power বাটন চাপুন', 'BIOS / লোগো স্ক্রিন আসবে — অপেক্ষা করুন', 'Windows লোড হবে', 'Password দিয়ে Login করে ডেস্কটপে ঢুকুন'];
const OFF = ['সব ফাইল Save করে প্রোগ্রাম বন্ধ করুন', 'Start (⊞) বাটনে ক্লিক করুন', 'Power ⏻ → Shut down চাপুন', 'স্ক্রিন কালো হলে মনিটর ও সুইচ বন্ধ করুন'];
const DESK = '🗂️ 📁 🌐<div class="tb"></div>';
const OF = {
  '📝 Word': 'Home|ফন্ট, সাইজ, Bold/Italic, Alignment, Bullets, Styles, Find & Replace;Insert|Table, Picture, Shape, Header/Footer, Page Number;Layout|Margins, Orientation, Size, Columns;References|Table of Contents, Footnote;Review|Spelling, Track Changes, Comment;View|Zoom, Print Layout, Ruler',
  '📊 Excel': 'Home|Number Format, Alignment, Conditional Formatting, Sort & Filter;Insert|PivotTable, Chart, Table;Formulas|AutoSum, Function Library;Data|Sort, Filter, Remove Duplicates, Data Validation;Review|Protect Sheet, Comment;View|Freeze Panes, Gridlines, Zoom',
  '📽️ PowerPoint': 'Home|New Slide, Layout, Font, Paragraph;Insert|Picture, Video, SmartArt, Chart;Design|Themes, Slide Size;Transitions|Fade, Push, Wipe;Animations|Entrance, Exit, Motion Path;Slide Show|From Beginning (F5), Presenter View'
};
const KEYS = [['Ctrl + C', 'কপি'], ['Ctrl + V', 'পেস্ট'], ['Ctrl + X', 'কাট'], ['Ctrl + Z / Y', 'আনডু / রিডু'], ['Ctrl + S', 'সেভ'], ['Ctrl + P', 'প্রিন্ট'], ['Ctrl + A', 'সব সিলেক্ট'], ['Ctrl + F', 'খুঁজুন (Find)'], ['Ctrl + H', 'Find & Replace'], ['Ctrl + B / I / U', 'Bold / Italic / Underline'], ['Ctrl + N / O', 'নতুন ফাইল / ফাইল ওপেন'], ['Ctrl + E / L / R', 'Center / Left / Right Align'], ['Ctrl + Enter', 'নতুন পেজ (Word)'], ['Alt + Tab', 'প্রোগ্রাম বদল'], ['Win + D', 'ডেস্কটপ দেখান'], ['Win + E', 'File Explorer'], ['Win + L', 'কম্পিউটার লক'], ['Alt + F4', 'প্রোগ্রাম বন্ধ'], ['F2 / F12', 'Rename / Save As'], ['F5', 'Slide Show শুরু (PowerPoint)'], ['Ctrl + ;', 'আজকের তারিখ (Excel)'], ['Ctrl + Shift + L', 'Filter চালু (Excel)'], ['Alt + =', 'AutoSum (Excel)'], ['Ctrl + Home / End', 'শীটের শুরু / শেষে যান']];
const XL = [
  ['B', 'SUM', '=SUM(B2:B10)', 'ঘরগুলোর মোট যোগফল', 'বেতন / বিলের মোট'],
  ['B', 'AVERAGE', '=AVERAGE(B2:B10)', 'গড় বের করা', 'রেজাল্টের গড়'],
  ['B', 'COUNT / COUNTA', '=COUNTA(A2:A50)', 'ভরা ঘর গোনা', 'উপস্থিতি গণনা'],
  ['B', 'MAX / MIN', '=MAX(B2:B10)', 'সর্বোচ্চ / সর্বনিম্ন মান', 'সর্বোচ্চ নম্বর'],
  ['B', 'ROUND', '=ROUND(B2*0.15,0)', 'দশমিক ঠিক করা', 'কমিশন, ভ্যাট'],
  ['B', 'TODAY / NOW', '=TODAY()', 'আজকের তারিখ / সময়', 'বিলের তারিখ'],
  ['B', 'TRIM / LEN', '=TRIM(A2)', 'বাড়তি স্পেস মোছা, অক্ষর গোনা', 'ডেটা পরিষ্কার'],
  ['I', 'IF', '=IF(B2>=33,"Pass","Fail")', 'শর্ত অনুযায়ী ফল', 'পাশ / ফেল'],
  ['I', 'IF + AND / OR', '=IF(AND(B2>=33,C2>=33),"Pass","Fail")', 'একাধিক শর্ত', 'গ্রেডিং'],
  ['I', 'COUNTIF', '=COUNTIF(C2:C50,"Due")', 'শর্ত মিলিয়ে গোনা', 'বাকি কয়জন'],
  ['I', 'SUMIF', '=SUMIF(C2:C50,"Paid",D2:D50)', 'শর্ত মিলিয়ে যোগ', 'আদায়ের মোট'],
  ['I', 'CONCAT / &', '=A2&" "&B2', 'লেখা জোড়া লাগানো', 'নাম একত্র করা'],
  ['I', 'LEFT / RIGHT / MID', '=LEFT(A2,3)', 'লেখার অংশ কাটা', 'আইডি কোড'],
  ['A', 'VLOOKUP', '=VLOOKUP(E2,A2:C50,3,FALSE)', 'তালিকা থেকে মান খোঁজা', 'মূল্য তালিকা'],
  ['A', 'XLOOKUP', '=XLOOKUP(E2,A:A,C:C,"নেই")', 'আধুনিক খোঁজার ফাংশন', 'স্টুডেন্ট সার্চ'],
  ['A', 'IFERROR', '=IFERROR(B2/C2,0)', 'Error লুকানো', 'পরিচ্ছন্ন রিপোর্ট'],
  ['A', 'SUMPRODUCT', '=SUMPRODUCT(B2:B9,C2:C9)', 'গুণ করে যোগ', 'পরিমাণ × দাম'],
  ['A', 'Pivot Table', 'Insert → PivotTable', 'ডেটার সারাংশ রিপোর্ট', 'মাসিক রিপোর্ট'],
  ['A', 'Conditional Formatting', 'Home → Conditional Formatting', 'রঙ দিয়ে হাইলাইট', 'বাকি টাকা লাল']
];
const TX = ['The quick brown fox jumps over the lazy dog.', 'Computer training helps students build a bright future.', 'Practice every day and your typing speed will grow fast.', 'Save your file often and press Ctrl plus S to stay safe.'];

let cur = 0, ver = 'web';
async function info() {
  if (P.App) { try { const a = await P.App.getInfo(); cur = parseInt(a.build) || 0; ver = a.version; } catch (e) {} }
}
async function latest() {
  const r = await fetch('https://api.github.com/repos/' + (window.CFG || {}).repo + '/releases/latest');
  if (!r.ok) throw new Error('http');
  const j = await r.json(), a = (j.assets || []).find(x => /\.apk$/i.test(x.name));
  return { n: parseInt(String(j.tag_name).replace(/\D/g, '')) || 0, url: a && a.browser_download_url, v: j.name || j.tag_name };
}

const V = {
  home: {
    t: 'SCTC Academy',
    h: () => { const d = (S.done || []).length, n = MODS.length - 1; return `<div class="hero"><b>স্বাগতম! 👋</b><span>${d}/${n} মডিউল দেখা হয়েছে</span><div class="bar"><i style="width:${Math.min(100, d / n * 100)}%"></i></div></div><div id="ub"></div><div class="grid">${MODS.map(m => `<button class="card" data-v="${m[0]}"><span class="ic">${m[1]}</span><b>${m[2]}</b><small>${m[3]}</small></button>`).join('')}</div>`; },
    i() { latest().then(u => { if (u.n > cur && u.url && $('#ub')) $('#ub').innerHTML = '<button class="btn" data-v="upd" style="width:100%;margin-bottom:12px">🆕 নতুন আপডেট এসেছে — আপডেট করুন</button>'; }).catch(() => {}); }
  },
  boot: {
    t: 'কম্পিউটার চালু ও বন্ধ',
    h: () => '<div class="stage"><div class="mon"><div class="scr" id="scr"></div></div><div class="neck"></div><div class="base"></div></div><div class="row"><button class="btn" id="on">⏻ চালু করুন</button><button class="btn alt" id="off">বন্ধ করুন</button></div><ol class="steps" id="stp"></ol>',
    i() {
      const sc = $('#scr'), sp = $('#stp');
      let run = 0;
      const set = (h, c) => { sc.className = 'scr ' + (c || ''); sc.innerHTML = h; };
      const st = (a, n) => { sp.innerHTML = a.map((s, k) => `<li class="${k === n ? 'on' : ''}">${s}</li>`).join(''); };
      const play = async (a, seq, end) => {
        const id = ++run;
        for (let k = 0; k < seq.length; k++) { st(a, k); set(seq[k][0], seq[k][1]); await wait(seq[k][2]); if (id !== run) return; }
        st(a, -1); set(end[0], end[1]);
      };
      set(''); st(ON, -1);
      $('#on').onclick = () => play(ON, [['', '', 900], ['<img src="logo.png"><div class="ld"><i></i></div>SCTC BIOS Check', '', 2300], ['<b>Windows</b><div class="sp"></div>', '', 2000], ['<b>👤 Login</b><p>Password → Enter</p>', '', 1800]], [DESK, 'dk']);
      $('#off').onclick = () => play(OFF, [[DESK, 'dk', 1300], ['<b>⊞ Start</b>', '', 1300], ['<b>⏻ Shut down</b>', '', 1300], ['<b>Shutting down…</b><div class="sp"></div>', '', 2200]], ['', '']);
    }
  },
  office: {
    t: 'অফিস অ্যাপ ও মেনু',
    h: () => Object.entries(OF).map(([k, v]) => `<details class="box"><summary>${k}</summary>${v.split(';').map(x => { const [a, b] = x.split('|'); return `<p><b>${E(a)}</b><br><small>${E(b)}</small></p>`; }).join('')}</details>`).join('')
  },
  keys: {
    t: 'শর্টকাট কী',
    h: () => '<input class="s" id="q" placeholder="🔍 খুঁজুন (Ctrl, Excel...)"><div id="kl"></div>',
    i() {
      const r = q => { $('#kl').innerHTML = KEYS.filter(k => (k[0] + k[1]).toLowerCase().includes(q.toLowerCase())).map(k => `<div class="box"><b style="color:#8be28a">${E(k[0])}</b><br>${E(k[1])}</div>`).join(''); };
      $('#q').oninput = e => r(e.target.value); r('');
    }
  },
  excel: {
    t: 'এক্সেল ফর্মুলা',
    h: () => `<div class="chips">${['all', 'B', 'I', 'A'].map(k => `<button class="chip${k === 'all' ? ' on' : ''}" data-f="${k}">${k === 'all' ? 'সব' : LV[k]}</button>`).join('')}</div><div id="xl"></div>`,
    i() {
      const r = f => { $('#xl').innerHTML = XL.filter(x => f === 'all' || x[0] === f).map(x => `<div class="box"><b>${E(x[1])}</b> <small>${LV[x[0]]}</small><code>${E(x[2])}</code>${E(x[3])}<br><small>কাজে লাগে: ${E(x[4])}</small></div>`).join(''); };
      r('all');
      $$('[data-f]').forEach(b => b.onclick = () => { $$('[data-f]').forEach(c => c.classList.toggle('on', c === b)); r(b.dataset.f); });
    }
  },
  type: {
    t: 'টাইপিং প্র্যাকটিস',
    h: () => `<div class="tbox" id="tx"></div><textarea id="ti" rows="3" autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="এখানে টাইপ করুন..."></textarea><div class="stats"><span id="w">0 WPM</span><span id="a">100%</span><span id="best">সেরা: ${S.best || 0}</span></div><button class="btn" id="nx" style="width:100%">নতুন লেখা ↻</button>`,
    i() {
      const ti = $('#ti'), tx = $('#tx');
      let tg = '', t0 = 0, n = 0;
      const draw = v => { tx.innerHTML = [...tg].map((c, k) => `<span class="${k < v.length ? (v[k] === c ? 'ok' : 'bad') : k === v.length ? 'cur' : ''}">${E(c)}</span>`).join(''); };
      const nw = () => { tg = TX[n++ % TX.length]; ti.value = ''; t0 = 0; ti.disabled = false; $('#w').textContent = '0 WPM'; $('#a').textContent = '100%'; draw(''); ti.focus(); };
      ti.oninput = () => {
        const v = ti.value.slice(0, tg.length);
        if (!t0) t0 = Date.now();
        draw(v);
        let ok = 0;
        for (let k = 0; k < v.length; k++) if (v[k] === tg[k]) ok++;
        const w = Math.round(ok / 5 / Math.max((Date.now() - t0) / 6e4, .02));
        $('#w').textContent = w + ' WPM';
        $('#a').textContent = (v.length ? Math.round(ok / v.length * 100) : 100) + '%';
        if (v.length >= tg.length) {
          ti.disabled = true;
          if (w > (S.best || 0)) { S.best = w; sv(); $('#best').textContent = 'সেরা: ' + w; toast('🎉 নতুন রেকর্ড!'); }
        }
      };
      $('#nx').onclick = nw; nw();
    }
  },
  upd: {
    t: 'অ্যাপ আপডেট',
    h: () => '<div class="box">বর্তমান ভার্সন: <b id="cv"></b></div><div class="box" id="us">নতুন ভার্সন খোঁজা হয়নি।</div><div class="bar"><i id="pb" style="width:0"></i></div><div class="row"><button class="btn" id="ck">আপডেট চেক করুন</button></div>',
    i() {
      const us = $('#us'), b = $('#ck');
      let u = null;
      $('#cv').textContent = ver;
      b.onclick = async () => {
        try {
          if (u) {
            if (!I) { toast('শুধু Android অ্যাপে কাজ করবে'); return; }
            b.disabled = true; us.textContent = 'ডাউনলোড হচ্ছে...';
            const h = await I.addListener('progress', e => { $('#pb').style.width = e.percent + '%'; });
            let r;
            try { r = await I.download({ url: u.url }); } finally { h.remove(); }
            us.textContent = 'ইনস্টল শুরু হচ্ছে...';
            await I.install({ path: r.path });
            b.disabled = false;
            return;
          }
          us.textContent = 'খোঁজা হচ্ছে...';
          const x = await latest();
          if (x.n > cur && x.url) { u = x; us.innerHTML = `🆕 নতুন ভার্সন: <b>${E(x.v)}</b>`; b.textContent = 'ডাউনলোড ও ইনস্টল'; }
          else us.textContent = '✅ আপনার অ্যাপ সর্বশেষ ভার্সনে আছে।';
        } catch (e) {
          b.disabled = false;
          us.textContent = e && e.code === 'NEED_PERMISSION' ? 'সেটিংসে "এই সোর্স থেকে ইনস্টল" অনুমতি চালু করে আবার চাপুন।' : 'ব্যর্থ হয়েছে। ইন্টারনেট ও রিলিজ চেক করুন।';
        }
      };
    }
  }
};

let stk = ['home'];
function show(v, push = true) {
  if (push) stk.push(v);
  const x = V[v];
  app.innerHTML = `<header>${v === 'home' ? '<img src="logo.png" alt="">' : '<button id="bk">‹</button>'}<h1>${x.t}</h1></header><main>${x.h()}</main>`;
  scrollTo(0, 0);
  if (v !== 'home' && v !== 'upd') { S.done = S.done || []; if (!S.done.includes(v)) { S.done.push(v); sv(); } }
  const k = $('#bk'); if (k) k.onclick = back;
  if (x.i) x.i();
}
function back() {
  if (stk.length > 1) { stk.pop(); show(stk[stk.length - 1], false); }
  else if (P.App) P.App.exitApp();
}
app.addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (b) show(b.dataset.v); });

(async () => {
  await info();
  show('home', false);
  setTimeout(() => { const s = $('#splash'); s.style.opacity = 0; setTimeout(() => s.remove(), 650); }, 2600);
  try { if (P.StatusBar) P.StatusBar.setBackgroundColor({ color: '#071a2f' }); } catch (e) {}
  if (P.App) P.App.addListener('backButton', back);
})();
})();
